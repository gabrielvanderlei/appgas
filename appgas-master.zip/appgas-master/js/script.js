  // Initialize Firebase
  var config = {
    apiKey: "AIzaSyBHqGRNhMZEn77wAWmPASBlYjcwSK6a-tw",
    authDomain: "projetoappgas-28d40.firebaseapp.com",
    databaseURL: "https://projetoappgas-28d40.firebaseio.com",
    projectId: "projetoappgas-28d40",
    storageBucket: "projetoappgas-28d40.appspot.com",
    messagingSenderId: "948773523425"
  };
  var pesoRef;
  var uuid;
  var batata=30;
  firebase.initializeApp(config);
  // Initialize Cloud Firestore through Firebase

  var db = firebase.firestore();
    
  function criarUsuario(){
    firebase.auth().createUserWithEmailAndPassword(document.getElementById('emailc').value,document.getElementById('senhac').value)
      .then(function(data){
          alert('Registrado');
      })
      .catch(function(error) {
        // Handle Errors here.
        var errorCode = error.code;
        var errorMessage = error.message;
        alert(errorMessage);
      });
  }
  
  function logarUsuario(){
    firebase.auth()
    .signInWithEmailAndPassword(document.getElementById('emaill').value,document.getElementById('senhal').value)
    .then(function(){
          alert("Logado!");
    })
    .catch(function(error) {
          // Handle Errors here.
          var errorCode = error.code;
          var errorMessage = error.message;
          alert(errorMessage);
    })
  }
  
  function show(id){
    $('.section').css('display', 'none');
    $('#'+id).css('display','block');
  }
  

 function carregarSensores(doc){
    var data = doc.data();
    document.getElementById("sensores").innerHTML = data.sensores;
  }

  firebase.auth().onAuthStateChanged(function(user) {
    if (user) {





var dba = firebase.database();

  // Cria os listeners dos dados no firebase
  pesoRef = dba.ref('peso');
  

  // Registrar fun��o ao alterar valor de presen�a
  pesoRef.on('value', function(snapshot){
    var value = snapshot.val();
    console.log("Peso agora: "+value);
    document.getElementById("sensores").innerHTML = value + "Kg"
    document.getElementById("username").innerHTML = value + "Kg"
  });





      // User is signed in.
      var displayName = user.displayName;
      var email = user.email;
      var emailVerified = user.emailVerified;
      var photoURL = user.photoURL;
      var isAnonymous = user.isAnonymous;
      
      uuid = user.uid;
      var providerData = user.providerData;


      var user=db.collection("users").doc(uuid).get().then(carregarSensores)
      .catch(function(){
              db.collection("users").doc(uuid).add({
                  email: user.email
              })
              .then(function(docRef) {
                  alert('Usu�rio configurado');
              })
              .catch(function(error) {
                  console.error("Error adding document: ", error);
              });
            // ...
      });
            
      document.getElementById('username').innerHTML = email;
      
      show('painel');
      carregarSensores();
    } else {
      // User is signed out.
      // ...
      show('main');
    }
  });
  


  function addSensor(){
      var user=db.collection("users").doc(uuid);
      user.set({
      sensores: $("#sensor").val()
      }, {merge: true });

      show("painel");
      carregarSensores();
  }

  function logOut(){
    firebase.auth().signOut().then(function() {
      // Sign-out successful.
      alert('Deslogado');
    }).catch(function(error) {
      // An error happened.
      alert('Algum erro ocorreu');
    });
  }

function Batata(){
     pesoRef.set(batata);
	batata++;
}
    